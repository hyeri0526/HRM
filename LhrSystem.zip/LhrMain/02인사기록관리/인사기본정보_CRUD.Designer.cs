﻿
namespace LhrMain
{
    partial class BasicFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BasicFrm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.search_panel = new System.Windows.Forms.Panel();
            this.q_bas_pos = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.q_bas_dept = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.q_bas_name = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.q_bas_empno = new System.Windows.Forms.TextBox();
            this.data_panel = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ct_bas_rmk = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ct_bas_img = new System.Windows.Forms.TextBox();
            this.btn_bas_dept = new System.Windows.Forms.Button();
            this.btn_bas_univ = new System.Windows.Forms.Button();
            this.btn_bas_zip = new System.Windows.Forms.Button();
            this.btnPDel = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnPic = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.ct_bas_addr2 = new System.Windows.Forms.TextBox();
            this.ct_bas_addrex = new System.Windows.Forms.TextBox();
            this.ct_bas_acc_bank = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.ct_bas_univ = new System.Windows.Forms.TextBox();
            this.ct_bas_empno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ct_bas_name = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ct_bas_mil = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ct_bas_cname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ct_bas_sex = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ct_bas_mar = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ct_bas_bth = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ct_bas_zip = new System.Windows.Forms.TextBox();
            this.ct_bas_reidate = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ct_bas_levdate = new System.Windows.Forms.MaskedTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.ct_bas_ename = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ct_bas_salary = new System.Windows.Forms.TextBox();
            this.ct_bas_acc_name = new System.Windows.Forms.TextBox();
            this.ct_bas_acc_no = new System.Windows.Forms.TextBox();
            this.ct_bas_addr1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.ct_bas_sta = new System.Windows.Forms.ComboBox();
            this.ct_bas_hdpno = new System.Windows.Forms.TextBox();
            this.ct_bas_jkp = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.ct_bas_pos = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.ct_bas_entdate = new System.Windows.Forms.MaskedTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.ct_bas_dptdate = new System.Windows.Forms.MaskedTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.ct_bas_jkpdate = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ct_bas_resdate = new System.Windows.Forms.MaskedTextBox();
            this.ct_bas_posdate = new System.Windows.Forms.MaskedTextBox();
            this.ct_bas_dept = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.bas_empno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dept = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_pos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_jkp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_cname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_ename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_sex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_bth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_mar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_hdpno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_univ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_zip = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_addr1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_addrex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_addr2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_sta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_entdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_resdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_dptdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_posdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_jkpdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_levdate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_reidate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_bank = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_acc_no = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_rmk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bas_img = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Key1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.search_panel.SuspendLayout();
            this.data_panel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 680F));
            this.tableLayoutPanel1.Controls.Add(this.search_panel, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.data_panel, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(967, 606);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // search_panel
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.search_panel, 2);
            this.search_panel.Controls.Add(this.q_bas_pos);
            this.search_panel.Controls.Add(this.label17);
            this.search_panel.Controls.Add(this.q_bas_dept);
            this.search_panel.Controls.Add(this.label16);
            this.search_panel.Controls.Add(this.label13);
            this.search_panel.Controls.Add(this.q_bas_name);
            this.search_panel.Controls.Add(this.label12);
            this.search_panel.Controls.Add(this.q_bas_empno);
            this.search_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.search_panel.Location = new System.Drawing.Point(5, 5);
            this.search_panel.Name = "search_panel";
            this.search_panel.Size = new System.Drawing.Size(957, 34);
            this.search_panel.TabIndex = 0;
            // 
            // q_bas_pos
            // 
            this.q_bas_pos.Location = new System.Drawing.Point(488, 12);
            this.q_bas_pos.Name = "q_bas_pos";
            this.q_bas_pos.Size = new System.Drawing.Size(89, 21);
            this.q_bas_pos.TabIndex = 24;
            this.q_bas_pos.Tag = "";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(453, 15);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 23;
            this.label17.Text = "직급";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // q_bas_dept
            // 
            this.q_bas_dept.Location = new System.Drawing.Point(343, 12);
            this.q_bas_dept.Name = "q_bas_dept";
            this.q_bas_dept.Size = new System.Drawing.Size(89, 21);
            this.q_bas_dept.TabIndex = 22;
            this.q_bas_dept.Tag = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(308, 15);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 21;
            this.label16.Text = "부서";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(172, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 20;
            this.label13.Text = "성명";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // q_bas_name
            // 
            this.q_bas_name.Location = new System.Drawing.Point(207, 12);
            this.q_bas_name.Name = "q_bas_name";
            this.q_bas_name.Size = new System.Drawing.Size(89, 21);
            this.q_bas_name.TabIndex = 19;
            this.q_bas_name.Tag = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 12);
            this.label12.TabIndex = 18;
            this.label12.Text = "사원번호";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // q_bas_empno
            // 
            this.q_bas_empno.Location = new System.Drawing.Point(68, 12);
            this.q_bas_empno.Name = "q_bas_empno";
            this.q_bas_empno.Size = new System.Drawing.Size(89, 21);
            this.q_bas_empno.TabIndex = 17;
            this.q_bas_empno.Tag = "";
            // 
            // data_panel
            // 
            this.data_panel.Controls.Add(this.groupBox2);
            this.data_panel.Controls.Add(this.groupBox1);
            this.data_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.data_panel.Location = new System.Drawing.Point(288, 47);
            this.data_panel.Name = "data_panel";
            this.data_panel.Size = new System.Drawing.Size(674, 554);
            this.data_panel.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ct_bas_rmk);
            this.groupBox2.Location = new System.Drawing.Point(3, 445);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(652, 106);
            this.groupBox2.TabIndex = 63;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "참고사항";
            // 
            // ct_bas_rmk
            // 
            this.ct_bas_rmk.Location = new System.Drawing.Point(16, 18);
            this.ct_bas_rmk.Multiline = true;
            this.ct_bas_rmk.Name = "ct_bas_rmk";
            this.ct_bas_rmk.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ct_bas_rmk.Size = new System.Drawing.Size(619, 82);
            this.ct_bas_rmk.TabIndex = 43;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ct_bas_img);
            this.groupBox1.Controls.Add(this.btn_bas_dept);
            this.groupBox1.Controls.Add(this.btn_bas_univ);
            this.groupBox1.Controls.Add(this.btn_bas_zip);
            this.groupBox1.Controls.Add(this.btnPDel);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.btnPic);
            this.groupBox1.Controls.Add(this.tableLayoutPanel2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(674, 554);
            this.groupBox1.TabIndex = 62;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "기본정보";
            // 
            // ct_bas_img
            // 
            this.ct_bas_img.Location = new System.Drawing.Point(16, 203);
            this.ct_bas_img.Name = "ct_bas_img";
            this.ct_bas_img.Size = new System.Drawing.Size(111, 21);
            this.ct_bas_img.TabIndex = 65;
            this.ct_bas_img.Visible = false;
            // 
            // btn_bas_dept
            // 
            this.btn_bas_dept.Image = ((System.Drawing.Image)(resources.GetObject("btn_bas_dept.Image")));
            this.btn_bas_dept.Location = new System.Drawing.Point(375, 258);
            this.btn_bas_dept.Name = "btn_bas_dept";
            this.btn_bas_dept.Size = new System.Drawing.Size(19, 19);
            this.btn_bas_dept.TabIndex = 31;
            this.btn_bas_dept.UseVisualStyleBackColor = true;
            this.btn_bas_dept.Click += new System.EventHandler(this.btn_bas_dept_Click);
            // 
            // btn_bas_univ
            // 
            this.btn_bas_univ.Image = ((System.Drawing.Image)(resources.GetObject("btn_bas_univ.Image")));
            this.btn_bas_univ.Location = new System.Drawing.Point(616, 142);
            this.btn_bas_univ.Name = "btn_bas_univ";
            this.btn_bas_univ.Size = new System.Drawing.Size(19, 19);
            this.btn_bas_univ.TabIndex = 23;
            this.btn_bas_univ.UseVisualStyleBackColor = true;
            this.btn_bas_univ.Click += new System.EventHandler(this.btn_bas_univ_Click);
            // 
            // btn_bas_zip
            // 
            this.btn_bas_zip.Image = global::LhrMain.Properties.Resources.search2;
            this.btn_bas_zip.Location = new System.Drawing.Point(358, 171);
            this.btn_bas_zip.Name = "btn_bas_zip";
            this.btn_bas_zip.Size = new System.Drawing.Size(19, 19);
            this.btn_bas_zip.TabIndex = 25;
            this.btn_bas_zip.UseVisualStyleBackColor = true;
            this.btn_bas_zip.Click += new System.EventHandler(this.btn_bas_zip_Click);
            // 
            // btnPDel
            // 
            this.btnPDel.Location = new System.Drawing.Point(74, 164);
            this.btnPDel.Name = "btnPDel";
            this.btnPDel.Size = new System.Drawing.Size(55, 22);
            this.btnPDel.TabIndex = 63;
            this.btnPDel.Text = "삭제";
            this.btnPDel.UseVisualStyleBackColor = true;
            this.btnPDel.Click += new System.EventHandler(this.btnPDel_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(17, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 64;
            this.pictureBox1.TabStop = false;
            // 
            // btnPic
            // 
            this.btnPic.Location = new System.Drawing.Point(17, 164);
            this.btnPic.Name = "btnPic";
            this.btnPic.Size = new System.Drawing.Size(55, 22);
            this.btnPic.TabIndex = 62;
            this.btnPic.Text = "등록";
            this.btnPic.UseVisualStyleBackColor = true;
            this.btnPic.Click += new System.EventHandler(this.btnPic_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 4;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_addr2, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_addrex, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_acc_bank, 1, 12);
            this.tableLayoutPanel2.Controls.Add(this.label23, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_univ, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_empno, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_name, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_mil, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_cname, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label1, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_sex, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label15, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_mar, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.label9, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_bth, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_zip, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_reidate, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.label27, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_levdate, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.label30, 0, 12);
            this.tableLayoutPanel2.Controls.Add(this.label7, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.label33, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_ename, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label31, 2, 12);
            this.tableLayoutPanel2.Controls.Add(this.label32, 0, 13);
            this.tableLayoutPanel2.Controls.Add(this.label29, 2, 13);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_salary, 3, 13);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_acc_name, 3, 12);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_acc_no, 1, 13);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_addr1, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label14, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label18, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_sta, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_hdpno, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_jkp, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.label21, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label20, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_pos, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_entdate, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label22, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_dptdate, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.label28, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.label24, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_jkpdate, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.label6, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_resdate, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_posdate, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.ct_bas_dept, 1, 8);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(133, 21);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 14;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(518, 406);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // ct_bas_addr2
            // 
            this.ct_bas_addr2.Location = new System.Drawing.Point(352, 178);
            this.ct_bas_addr2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_addr2.Name = "ct_bas_addr2";
            this.ct_bas_addr2.Size = new System.Drawing.Size(151, 21);
            this.ct_bas_addr2.TabIndex = 65;
            // 
            // ct_bas_addrex
            // 
            this.ct_bas_addrex.Location = new System.Drawing.Point(262, 178);
            this.ct_bas_addrex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_addrex.Name = "ct_bas_addrex";
            this.ct_bas_addrex.Size = new System.Drawing.Size(75, 21);
            this.ct_bas_addrex.TabIndex = 66;
            // 
            // ct_bas_acc_bank
            // 
            this.ct_bas_acc_bank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ct_bas_acc_bank.FormattingEnabled = true;
            this.ct_bas_acc_bank.Location = new System.Drawing.Point(93, 352);
            this.ct_bas_acc_bank.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_acc_bank.Name = "ct_bas_acc_bank";
            this.ct_bas_acc_bank.Size = new System.Drawing.Size(150, 20);
            this.ct_bas_acc_bank.TabIndex = 39;
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(274, 269);
            this.label23.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 12);
            this.label23.TabIndex = 94;
            this.label23.Text = "현직급일자";
            // 
            // ct_bas_univ
            // 
            this.ct_bas_univ.Location = new System.Drawing.Point(352, 120);
            this.ct_bas_univ.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_univ.MaxLength = 5;
            this.ct_bas_univ.Name = "ct_bas_univ";
            this.ct_bas_univ.Size = new System.Drawing.Size(130, 21);
            this.ct_bas_univ.TabIndex = 22;
            this.ct_bas_univ.Tag = "";
            // 
            // ct_bas_empno
            // 
            this.ct_bas_empno.Location = new System.Drawing.Point(93, 4);
            this.ct_bas_empno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_empno.MaxLength = 5;
            this.ct_bas_empno.Name = "ct_bas_empno";
            this.ct_bas_empno.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_empno.TabIndex = 13;
            this.ct_bas_empno.Tag = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 10);
            this.label2.Margin = new System.Windows.Forms.Padding(15, 10, 3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "사원번호";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(274, 10);
            this.label3.Margin = new System.Windows.Forms.Padding(15, 10, 3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 15;
            this.label3.Text = "성명";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_name
            // 
            this.ct_bas_name.Location = new System.Drawing.Point(352, 4);
            this.ct_bas_name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_name.MaxLength = 5;
            this.ct_bas_name.Name = "ct_bas_name";
            this.ct_bas_name.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_name.TabIndex = 14;
            this.ct_bas_name.Tag = "";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 95);
            this.label8.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 36;
            this.label8.Text = "병역구분";
            // 
            // ct_bas_mil
            // 
            this.ct_bas_mil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ct_bas_mil.FormattingEnabled = true;
            this.ct_bas_mil.Items.AddRange(new object[] {
            "복무",
            "면제",
            "미필"});
            this.ct_bas_mil.Location = new System.Drawing.Point(93, 91);
            this.ct_bas_mil.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_mil.Name = "ct_bas_mil";
            this.ct_bas_mil.Size = new System.Drawing.Size(150, 20);
            this.ct_bas_mil.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 37);
            this.label4.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "성명(한자)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_cname
            // 
            this.ct_bas_cname.Location = new System.Drawing.Point(93, 33);
            this.ct_bas_cname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_cname.MaxLength = 5;
            this.ct_bas_cname.Name = "ct_bas_cname";
            this.ct_bas_cname.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_cname.TabIndex = 15;
            this.ct_bas_cname.Tag = "";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 66);
            this.label5.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 21;
            this.label5.Text = "성별";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 12);
            this.label1.TabIndex = 17;
            this.label1.Text = "성명(영어)";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_sex
            // 
            this.ct_bas_sex.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ct_bas_sex.FormattingEnabled = true;
            this.ct_bas_sex.Items.AddRange(new object[] {
            "남",
            "여"});
            this.ct_bas_sex.Location = new System.Drawing.Point(93, 62);
            this.ct_bas_sex.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_sex.Name = "ct_bas_sex";
            this.ct_bas_sex.Size = new System.Drawing.Size(150, 20);
            this.ct_bas_sex.TabIndex = 17;
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(274, 95);
            this.label15.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 12);
            this.label15.TabIndex = 37;
            this.label15.Text = "결혼여부";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_mar
            // 
            this.ct_bas_mar.AutoSize = true;
            this.ct_bas_mar.Location = new System.Drawing.Point(352, 91);
            this.ct_bas_mar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_mar.Name = "ct_bas_mar";
            this.ct_bas_mar.Size = new System.Drawing.Size(15, 14);
            this.ct_bas_mar.TabIndex = 20;
            this.ct_bas_mar.Tag = "";
            this.ct_bas_mar.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(274, 66);
            this.label9.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 29;
            this.label9.Text = "생년월일";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_bth
            // 
            this.ct_bas_bth.Location = new System.Drawing.Point(352, 62);
            this.ct_bas_bth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_bth.Mask = "0000-00-00";
            this.ct_bas_bth.Name = "ct_bas_bth";
            this.ct_bas_bth.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_bth.TabIndex = 18;
            this.ct_bas_bth.ValidatingType = typeof(System.DateTime);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 153);
            this.label10.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 32;
            this.label10.Text = "우편번호";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_zip
            // 
            this.ct_bas_zip.Location = new System.Drawing.Point(93, 149);
            this.ct_bas_zip.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_zip.MaxLength = 5;
            this.ct_bas_zip.Name = "ct_bas_zip";
            this.ct_bas_zip.Size = new System.Drawing.Size(130, 21);
            this.ct_bas_zip.TabIndex = 24;
            this.ct_bas_zip.Tag = "";
            // 
            // ct_bas_reidate
            // 
            this.ct_bas_reidate.Location = new System.Drawing.Point(352, 323);
            this.ct_bas_reidate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_reidate.Mask = "0000-00-00";
            this.ct_bas_reidate.Name = "ct_bas_reidate";
            this.ct_bas_reidate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_reidate.TabIndex = 38;
            this.ct_bas_reidate.ValidatingType = typeof(System.DateTime);
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(15, 327);
            this.label27.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 68;
            this.label27.Text = "휴직일자";
            // 
            // ct_bas_levdate
            // 
            this.ct_bas_levdate.Location = new System.Drawing.Point(93, 323);
            this.ct_bas_levdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_levdate.Mask = "0000-00-00";
            this.ct_bas_levdate.Name = "ct_bas_levdate";
            this.ct_bas_levdate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_levdate.TabIndex = 37;
            this.ct_bas_levdate.ValidatingType = typeof(System.DateTime);
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(15, 356);
            this.label30.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 12);
            this.label30.TabIndex = 71;
            this.label30.Text = "은행";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(274, 124);
            this.label7.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 25;
            this.label7.Text = "출신대학";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(15, 124);
            this.label33.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(41, 12);
            this.label33.TabIndex = 90;
            this.label33.Text = "휴대폰";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ct_bas_ename
            // 
            this.ct_bas_ename.Location = new System.Drawing.Point(352, 33);
            this.ct_bas_ename.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_ename.MaxLength = 20;
            this.ct_bas_ename.Name = "ct_bas_ename";
            this.ct_bas_ename.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_ename.TabIndex = 16;
            this.ct_bas_ename.Tag = "";
            // 
            // label31
            // 
            this.label31.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(274, 356);
            this.label31.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 12);
            this.label31.TabIndex = 72;
            this.label31.Text = "예금주";
            // 
            // label32
            // 
            this.label32.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(15, 385);
            this.label32.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 12);
            this.label32.TabIndex = 73;
            this.label32.Text = "계좌번호";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(274, 385);
            this.label29.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 12);
            this.label29.TabIndex = 70;
            this.label29.Text = "연봉";
            // 
            // ct_bas_salary
            // 
            this.ct_bas_salary.Location = new System.Drawing.Point(352, 381);
            this.ct_bas_salary.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_salary.Name = "ct_bas_salary";
            this.ct_bas_salary.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_salary.TabIndex = 42;
            // 
            // ct_bas_acc_name
            // 
            this.ct_bas_acc_name.Location = new System.Drawing.Point(352, 352);
            this.ct_bas_acc_name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_acc_name.MaxLength = 5;
            this.ct_bas_acc_name.Name = "ct_bas_acc_name";
            this.ct_bas_acc_name.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_acc_name.TabIndex = 40;
            this.ct_bas_acc_name.Tag = "";
            // 
            // ct_bas_acc_no
            // 
            this.ct_bas_acc_no.Location = new System.Drawing.Point(93, 381);
            this.ct_bas_acc_no.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_acc_no.MaxLength = 20;
            this.ct_bas_acc_no.Name = "ct_bas_acc_no";
            this.ct_bas_acc_no.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_acc_no.TabIndex = 41;
            this.ct_bas_acc_no.Tag = "";
            // 
            // ct_bas_addr1
            // 
            this.ct_bas_addr1.Location = new System.Drawing.Point(93, 178);
            this.ct_bas_addr1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_addr1.MaxLength = 50;
            this.ct_bas_addr1.Name = "ct_bas_addr1";
            this.ct_bas_addr1.Size = new System.Drawing.Size(151, 21);
            this.ct_bas_addr1.TabIndex = 27;
            this.ct_bas_addr1.Tag = "";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(15, 182);
            this.label14.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 34;
            this.label14.Text = "주소";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(274, 153);
            this.label18.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 12);
            this.label18.TabIndex = 40;
            this.label18.Text = "재직상태";
            // 
            // ct_bas_sta
            // 
            this.ct_bas_sta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ct_bas_sta.FormattingEnabled = true;
            this.ct_bas_sta.Items.AddRange(new object[] {
            "재직",
            "휴직",
            "퇴직"});
            this.ct_bas_sta.Location = new System.Drawing.Point(352, 149);
            this.ct_bas_sta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_sta.Name = "ct_bas_sta";
            this.ct_bas_sta.Size = new System.Drawing.Size(150, 20);
            this.ct_bas_sta.TabIndex = 26;
            // 
            // ct_bas_hdpno
            // 
            this.ct_bas_hdpno.Location = new System.Drawing.Point(93, 120);
            this.ct_bas_hdpno.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_hdpno.Name = "ct_bas_hdpno";
            this.ct_bas_hdpno.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_hdpno.TabIndex = 21;
            // 
            // ct_bas_jkp
            // 
            this.ct_bas_jkp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ct_bas_jkp.FormattingEnabled = true;
            this.ct_bas_jkp.Location = new System.Drawing.Point(93, 294);
            this.ct_bas_jkp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_jkp.Name = "ct_bas_jkp";
            this.ct_bas_jkp.Size = new System.Drawing.Size(150, 20);
            this.ct_bas_jkp.TabIndex = 35;
            // 
            // label21
            // 
            this.label21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(15, 298);
            this.label21.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(29, 12);
            this.label21.TabIndex = 62;
            this.label21.Text = "직책";
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 269);
            this.label20.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 42;
            this.label20.Text = "직급";
            // 
            // ct_bas_pos
            // 
            this.ct_bas_pos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ct_bas_pos.FormattingEnabled = true;
            this.ct_bas_pos.Location = new System.Drawing.Point(93, 265);
            this.ct_bas_pos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_pos.Name = "ct_bas_pos";
            this.ct_bas_pos.Size = new System.Drawing.Size(150, 20);
            this.ct_bas_pos.TabIndex = 33;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 240);
            this.label19.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 12);
            this.label19.TabIndex = 41;
            this.label19.Text = "부서";
            // 
            // label25
            // 
            this.label25.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 211);
            this.label25.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 66;
            this.label25.Text = "입사일자";
            // 
            // ct_bas_entdate
            // 
            this.ct_bas_entdate.Location = new System.Drawing.Point(93, 207);
            this.ct_bas_entdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_entdate.Mask = "0000-00-00";
            this.ct_bas_entdate.Name = "ct_bas_entdate";
            this.ct_bas_entdate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_entdate.TabIndex = 28;
            this.ct_bas_entdate.ValidatingType = typeof(System.DateTime);
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(274, 240);
            this.label22.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(65, 12);
            this.label22.TabIndex = 63;
            this.label22.Text = "현부서일자";
            // 
            // ct_bas_dptdate
            // 
            this.ct_bas_dptdate.Location = new System.Drawing.Point(352, 236);
            this.ct_bas_dptdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_dptdate.Mask = "0000-00-00";
            this.ct_bas_dptdate.Name = "ct_bas_dptdate";
            this.ct_bas_dptdate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_dptdate.TabIndex = 32;
            this.ct_bas_dptdate.ValidatingType = typeof(System.DateTime);
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(274, 327);
            this.label28.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 69;
            this.label28.Text = "복직일자";
            // 
            // label24
            // 
            this.label24.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(274, 298);
            this.label24.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 12);
            this.label24.TabIndex = 65;
            this.label24.Text = "현직책일자";
            // 
            // ct_bas_jkpdate
            // 
            this.ct_bas_jkpdate.Location = new System.Drawing.Point(352, 294);
            this.ct_bas_jkpdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_jkpdate.Mask = "0000-00-00";
            this.ct_bas_jkpdate.Name = "ct_bas_jkpdate";
            this.ct_bas_jkpdate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_jkpdate.TabIndex = 36;
            this.ct_bas_jkpdate.ValidatingType = typeof(System.DateTime);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 211);
            this.label6.Margin = new System.Windows.Forms.Padding(15, 0, 3, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 92;
            this.label6.Text = "퇴사일자";
            // 
            // ct_bas_resdate
            // 
            this.ct_bas_resdate.Location = new System.Drawing.Point(352, 207);
            this.ct_bas_resdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_resdate.Mask = "0000-00-00";
            this.ct_bas_resdate.Name = "ct_bas_resdate";
            this.ct_bas_resdate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_resdate.TabIndex = 29;
            // 
            // ct_bas_posdate
            // 
            this.ct_bas_posdate.Location = new System.Drawing.Point(352, 265);
            this.ct_bas_posdate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_posdate.Mask = "0000-00-00";
            this.ct_bas_posdate.Name = "ct_bas_posdate";
            this.ct_bas_posdate.Size = new System.Drawing.Size(150, 21);
            this.ct_bas_posdate.TabIndex = 34;
            // 
            // ct_bas_dept
            // 
            this.ct_bas_dept.Location = new System.Drawing.Point(93, 236);
            this.ct_bas_dept.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_bas_dept.Name = "ct_bas_dept";
            this.ct_bas_dept.Size = new System.Drawing.Size(130, 21);
            this.ct_bas_dept.TabIndex = 30;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.bas_empno,
            this.bas_name,
            this.bas_dept,
            this.bas_pos,
            this.bas_jkp,
            this.bas_cname,
            this.bas_ename,
            this.bas_sex,
            this.bas_bth,
            this.bas_mil,
            this.bas_mar,
            this.bas_hdpno,
            this.bas_univ,
            this.bas_zip,
            this.bas_addr1,
            this.bas_addrex,
            this.bas_addr2,
            this.bas_sta,
            this.bas_entdate,
            this.bas_resdate,
            this.bas_dptdate,
            this.bas_posdate,
            this.bas_jkpdate,
            this.bas_levdate,
            this.bas_reidate,
            this.bas_acc_bank,
            this.bas_acc_name,
            this.bas_acc_no,
            this.bas_salary,
            this.bas_rmk,
            this.bas_img,
            this.Key1,
            this.status});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(12, 54);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(10, 10, 3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(268, 547);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.DataList_SelectionChanged);
            // 
            // bas_empno
            // 
            this.bas_empno.HeaderText = "사원번호";
            this.bas_empno.Name = "bas_empno";
            this.bas_empno.ReadOnly = true;
            this.bas_empno.Width = 80;
            // 
            // bas_name
            // 
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.bas_name.DefaultCellStyle = dataGridViewCellStyle19;
            this.bas_name.HeaderText = "성명";
            this.bas_name.Name = "bas_name";
            this.bas_name.ReadOnly = true;
            this.bas_name.Width = 60;
            // 
            // bas_dept
            // 
            this.bas_dept.FillWeight = 80F;
            this.bas_dept.HeaderText = "부서";
            this.bas_dept.Name = "bas_dept";
            this.bas_dept.ReadOnly = true;
            // 
            // bas_pos
            // 
            this.bas_pos.HeaderText = "직급";
            this.bas_pos.Name = "bas_pos";
            this.bas_pos.ReadOnly = true;
            // 
            // bas_jkp
            // 
            this.bas_jkp.HeaderText = "직책";
            this.bas_jkp.Name = "bas_jkp";
            this.bas_jkp.ReadOnly = true;
            // 
            // bas_cname
            // 
            this.bas_cname.HeaderText = "성명(한자)";
            this.bas_cname.Name = "bas_cname";
            this.bas_cname.ReadOnly = true;
            // 
            // bas_ename
            // 
            this.bas_ename.HeaderText = "성명(영문)";
            this.bas_ename.Name = "bas_ename";
            this.bas_ename.ReadOnly = true;
            // 
            // bas_sex
            // 
            this.bas_sex.HeaderText = "성별";
            this.bas_sex.Name = "bas_sex";
            this.bas_sex.ReadOnly = true;
            this.bas_sex.Width = 60;
            // 
            // bas_bth
            // 
            this.bas_bth.HeaderText = "생년월일";
            this.bas_bth.Name = "bas_bth";
            this.bas_bth.ReadOnly = true;
            // 
            // bas_mil
            // 
            this.bas_mil.HeaderText = "병역구분";
            this.bas_mil.Name = "bas_mil";
            this.bas_mil.ReadOnly = true;
            // 
            // bas_mar
            // 
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle20.NullValue = "False";
            this.bas_mar.DefaultCellStyle = dataGridViewCellStyle20;
            this.bas_mar.HeaderText = "결혼여부";
            this.bas_mar.Name = "bas_mar";
            this.bas_mar.ReadOnly = true;
            this.bas_mar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // bas_hdpno
            // 
            this.bas_hdpno.HeaderText = "휴대폰";
            this.bas_hdpno.Name = "bas_hdpno";
            this.bas_hdpno.ReadOnly = true;
            // 
            // bas_univ
            // 
            this.bas_univ.HeaderText = "출신대학";
            this.bas_univ.Name = "bas_univ";
            this.bas_univ.ReadOnly = true;
            // 
            // bas_zip
            // 
            this.bas_zip.HeaderText = "우편번호";
            this.bas_zip.Name = "bas_zip";
            this.bas_zip.ReadOnly = true;
            // 
            // bas_addr1
            // 
            this.bas_addr1.HeaderText = "주소";
            this.bas_addr1.Name = "bas_addr1";
            this.bas_addr1.ReadOnly = true;
            // 
            // bas_addrex
            // 
            this.bas_addrex.HeaderText = "주소참고";
            this.bas_addrex.Name = "bas_addrex";
            this.bas_addrex.ReadOnly = true;
            // 
            // bas_addr2
            // 
            this.bas_addr2.HeaderText = "상세주소";
            this.bas_addr2.Name = "bas_addr2";
            this.bas_addr2.ReadOnly = true;
            // 
            // bas_sta
            // 
            this.bas_sta.HeaderText = "재직상태";
            this.bas_sta.Name = "bas_sta";
            this.bas_sta.ReadOnly = true;
            // 
            // bas_entdate
            // 
            this.bas_entdate.HeaderText = "입사일자";
            this.bas_entdate.Name = "bas_entdate";
            this.bas_entdate.ReadOnly = true;
            // 
            // bas_resdate
            // 
            this.bas_resdate.HeaderText = "퇴사일자";
            this.bas_resdate.Name = "bas_resdate";
            this.bas_resdate.ReadOnly = true;
            // 
            // bas_dptdate
            // 
            this.bas_dptdate.HeaderText = "현부서일자";
            this.bas_dptdate.Name = "bas_dptdate";
            this.bas_dptdate.ReadOnly = true;
            // 
            // bas_posdate
            // 
            this.bas_posdate.HeaderText = "현직급일자";
            this.bas_posdate.Name = "bas_posdate";
            this.bas_posdate.ReadOnly = true;
            // 
            // bas_jkpdate
            // 
            this.bas_jkpdate.HeaderText = "현직책일자";
            this.bas_jkpdate.Name = "bas_jkpdate";
            this.bas_jkpdate.ReadOnly = true;
            // 
            // bas_levdate
            // 
            this.bas_levdate.HeaderText = "휴직일자";
            this.bas_levdate.Name = "bas_levdate";
            this.bas_levdate.ReadOnly = true;
            // 
            // bas_reidate
            // 
            this.bas_reidate.HeaderText = "복직일자";
            this.bas_reidate.Name = "bas_reidate";
            this.bas_reidate.ReadOnly = true;
            // 
            // bas_acc_bank
            // 
            this.bas_acc_bank.HeaderText = "은행명";
            this.bas_acc_bank.Name = "bas_acc_bank";
            this.bas_acc_bank.ReadOnly = true;
            // 
            // bas_acc_name
            // 
            this.bas_acc_name.HeaderText = "예금주";
            this.bas_acc_name.Name = "bas_acc_name";
            this.bas_acc_name.ReadOnly = true;
            // 
            // bas_acc_no
            // 
            this.bas_acc_no.HeaderText = "계좌번호";
            this.bas_acc_no.Name = "bas_acc_no";
            this.bas_acc_no.ReadOnly = true;
            // 
            // bas_salary
            // 
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle21.Format = "N0";
            dataGridViewCellStyle21.NullValue = "0";
            this.bas_salary.DefaultCellStyle = dataGridViewCellStyle21;
            this.bas_salary.HeaderText = "연봉";
            this.bas_salary.Name = "bas_salary";
            this.bas_salary.ReadOnly = true;
            // 
            // bas_rmk
            // 
            this.bas_rmk.HeaderText = "참고사항";
            this.bas_rmk.Name = "bas_rmk";
            this.bas_rmk.ReadOnly = true;
            this.bas_rmk.Visible = false;
            // 
            // bas_img
            // 
            this.bas_img.HeaderText = "증명사진";
            this.bas_img.Name = "bas_img";
            this.bas_img.ReadOnly = true;
            this.bas_img.Visible = false;
            // 
            // Key1
            // 
            this.Key1.HeaderText = "Key1";
            this.Key1.Name = "Key1";
            this.Key1.ReadOnly = true;
            this.Key1.Visible = false;
            // 
            // status
            // 
            this.status.HeaderText = "status";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Visible = false;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(95, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 34;
            this.label11.Text = "휴대폰";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // BasicFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(967, 606);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "BasicFrm";
            this.Text = "인사기본정보(CRUD)";
            this.Load += new System.EventHandler(this.BasicFrm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.search_panel.ResumeLayout(false);
            this.search_panel.PerformLayout();
            this.data_panel.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel search_panel;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox q_bas_name;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox q_bas_empno;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel data_panel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox q_bas_pos;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox q_bas_dept;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox ct_bas_rmk;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPDel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnPic;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox ct_bas_empno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ct_bas_name;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ct_bas_ename;
        private System.Windows.Forms.TextBox ct_bas_cname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox ct_bas_mil;
        private System.Windows.Forms.TextBox ct_bas_zip;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox ct_bas_sex;
        private System.Windows.Forms.MaskedTextBox ct_bas_bth;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox ct_bas_mar;
        private System.Windows.Forms.TextBox ct_bas_acc_name;
        private System.Windows.Forms.ComboBox ct_bas_sta;
        private System.Windows.Forms.ComboBox ct_bas_pos;
        private System.Windows.Forms.ComboBox ct_bas_jkp;
        private System.Windows.Forms.MaskedTextBox ct_bas_entdate;
        private System.Windows.Forms.MaskedTextBox ct_bas_dptdate;
        private System.Windows.Forms.MaskedTextBox ct_bas_jkpdate;
        private System.Windows.Forms.MaskedTextBox ct_bas_levdate;
        private System.Windows.Forms.MaskedTextBox ct_bas_reidate;
        private System.Windows.Forms.TextBox ct_bas_salary;
        private System.Windows.Forms.Button btn_bas_zip;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.TextBox ct_bas_univ;
        private System.Windows.Forms.Button btn_bas_univ;
        private System.Windows.Forms.TextBox ct_bas_addr1;
        private System.Windows.Forms.TextBox ct_bas_hdpno;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MaskedTextBox ct_bas_resdate;
        private System.Windows.Forms.MaskedTextBox ct_bas_posdate;
        private System.Windows.Forms.Button btn_bas_dept;
        private System.Windows.Forms.TextBox ct_bas_acc_no;
        private System.Windows.Forms.TextBox ct_bas_dept;
        private System.Windows.Forms.ComboBox ct_bas_acc_bank;
        private System.Windows.Forms.TextBox ct_bas_addr2;
        private System.Windows.Forms.TextBox ct_bas_addrex;
        private System.Windows.Forms.TextBox ct_bas_img;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_empno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dept;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_pos;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_jkp;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_cname;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_ename;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_sex;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_bth;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mil;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_mar;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_hdpno;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_univ;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_zip;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_addr1;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_addrex;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_addr2;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_sta;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_entdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_resdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_dptdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_posdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_jkpdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_levdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_reidate;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_bank;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_name;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_acc_no;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_salary;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_rmk;
        private System.Windows.Forms.DataGridViewTextBoxColumn bas_img;
        private System.Windows.Forms.DataGridViewTextBoxColumn Key1;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
    }
}