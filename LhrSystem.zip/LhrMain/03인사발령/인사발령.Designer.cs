﻿
namespace LhrMain._03인사발령
{
    partial class 인사발령
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.data_panel = new System.Windows.Forms.Panel();
            this.btn_papp_empno = new System.Windows.Forms.Button();
            this.btn_papp_appno = new System.Windows.Forms.Button();
            this.ct_papp_rmk = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ct_papp_jkp_nm = new System.Windows.Forms.TextBox();
            this.ct_papp_pos_nm = new System.Windows.Forms.TextBox();
            this.ct_papp_dept_nm = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ct_papp_jkp_cd = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ct_papp_pos_cd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ct_papp_dept_cd = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ct_papp_basis = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ct_papp_auth = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ct_papp_appno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ct_papp_date = new System.Windows.Forms.MaskedTextBox();
            this.ct_papp_content = new System.Windows.Forms.TextBox();
            this.ct_papp_pap = new System.Windows.Forms.TextBox();
            this.ct_papp_empno = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.papp_empno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_appno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_pap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_content = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_auth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_basis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_dept_cd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_pos_cd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_jkp_cd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_dept_nm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_pos_nm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_jkp_nm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.papp_rmk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.data_panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280F));
            this.tableLayoutPanel1.Controls.Add(this.data_panel, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(884, 471);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // data_panel
            // 
            this.data_panel.Controls.Add(this.btn_papp_empno);
            this.data_panel.Controls.Add(this.btn_papp_appno);
            this.data_panel.Controls.Add(this.ct_papp_rmk);
            this.data_panel.Controls.Add(this.label14);
            this.data_panel.Controls.Add(this.ct_papp_jkp_nm);
            this.data_panel.Controls.Add(this.ct_papp_pos_nm);
            this.data_panel.Controls.Add(this.ct_papp_dept_nm);
            this.data_panel.Controls.Add(this.label13);
            this.data_panel.Controls.Add(this.label12);
            this.data_panel.Controls.Add(this.label11);
            this.data_panel.Controls.Add(this.ct_papp_jkp_cd);
            this.data_panel.Controls.Add(this.label10);
            this.data_panel.Controls.Add(this.ct_papp_pos_cd);
            this.data_panel.Controls.Add(this.label9);
            this.data_panel.Controls.Add(this.ct_papp_dept_cd);
            this.data_panel.Controls.Add(this.label8);
            this.data_panel.Controls.Add(this.ct_papp_basis);
            this.data_panel.Controls.Add(this.label7);
            this.data_panel.Controls.Add(this.ct_papp_auth);
            this.data_panel.Controls.Add(this.label6);
            this.data_panel.Controls.Add(this.ct_papp_appno);
            this.data_panel.Controls.Add(this.label5);
            this.data_panel.Controls.Add(this.ct_papp_date);
            this.data_panel.Controls.Add(this.ct_papp_content);
            this.data_panel.Controls.Add(this.ct_papp_pap);
            this.data_panel.Controls.Add(this.ct_papp_empno);
            this.data_panel.Controls.Add(this.label4);
            this.data_panel.Controls.Add(this.label3);
            this.data_panel.Controls.Add(this.label2);
            this.data_panel.Controls.Add(this.label1);
            this.data_panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.data_panel.Location = new System.Drawing.Point(607, 3);
            this.data_panel.Name = "data_panel";
            this.data_panel.Size = new System.Drawing.Size(274, 465);
            this.data_panel.TabIndex = 15;
            // 
            // btn_papp_empno
            // 
            this.btn_papp_empno.Image = global::LhrMain.Properties.Resources.search2;
            this.btn_papp_empno.Location = new System.Drawing.Point(230, 20);
            this.btn_papp_empno.Name = "btn_papp_empno";
            this.btn_papp_empno.Size = new System.Drawing.Size(19, 19);
            this.btn_papp_empno.TabIndex = 2;
            this.btn_papp_empno.UseVisualStyleBackColor = true;
            this.btn_papp_empno.Click += new System.EventHandler(this.btn_papp_empno_Click);
            // 
            // btn_papp_appno
            // 
            this.btn_papp_appno.Image = global::LhrMain.Properties.Resources.search2;
            this.btn_papp_appno.Location = new System.Drawing.Point(230, 53);
            this.btn_papp_appno.Name = "btn_papp_appno";
            this.btn_papp_appno.Size = new System.Drawing.Size(19, 19);
            this.btn_papp_appno.TabIndex = 4;
            this.btn_papp_appno.UseVisualStyleBackColor = true;
            this.btn_papp_appno.Click += new System.EventHandler(this.btn_papp_appno_Click);
            // 
            // ct_papp_rmk
            // 
            this.ct_papp_rmk.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_rmk.Location = new System.Drawing.Point(109, 429);
            this.ct_papp_rmk.Name = "ct_papp_rmk";
            this.ct_papp_rmk.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_rmk.TabIndex = 16;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(23, 432);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(29, 12);
            this.label14.TabIndex = 20;
            this.label14.Text = "비고";
            // 
            // ct_papp_jkp_nm
            // 
            this.ct_papp_jkp_nm.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_jkp_nm.Location = new System.Drawing.Point(109, 398);
            this.ct_papp_jkp_nm.Name = "ct_papp_jkp_nm";
            this.ct_papp_jkp_nm.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_jkp_nm.TabIndex = 15;
            // 
            // ct_papp_pos_nm
            // 
            this.ct_papp_pos_nm.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_pos_nm.Location = new System.Drawing.Point(109, 366);
            this.ct_papp_pos_nm.Name = "ct_papp_pos_nm";
            this.ct_papp_pos_nm.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_pos_nm.TabIndex = 14;
            // 
            // ct_papp_dept_nm
            // 
            this.ct_papp_dept_nm.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_dept_nm.Location = new System.Drawing.Point(109, 332);
            this.ct_papp_dept_nm.Name = "ct_papp_dept_nm";
            this.ct_papp_dept_nm.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_dept_nm.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(23, 401);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 12);
            this.label13.TabIndex = 19;
            this.label13.Text = "직책명";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(23, 369);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 18;
            this.label12.Text = "직급명";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(23, 335);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 17;
            this.label11.Text = "부서명";
            // 
            // ct_papp_jkp_cd
            // 
            this.ct_papp_jkp_cd.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_jkp_cd.Location = new System.Drawing.Point(109, 300);
            this.ct_papp_jkp_cd.Name = "ct_papp_jkp_cd";
            this.ct_papp_jkp_cd.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_jkp_cd.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(23, 303);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "직책코드";
            // 
            // ct_papp_pos_cd
            // 
            this.ct_papp_pos_cd.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_pos_cd.Location = new System.Drawing.Point(109, 267);
            this.ct_papp_pos_cd.Name = "ct_papp_pos_cd";
            this.ct_papp_pos_cd.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_pos_cd.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 270);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 13;
            this.label9.Text = "직급코드";
            // 
            // ct_papp_dept_cd
            // 
            this.ct_papp_dept_cd.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_dept_cd.Location = new System.Drawing.Point(109, 234);
            this.ct_papp_dept_cd.Name = "ct_papp_dept_cd";
            this.ct_papp_dept_cd.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_dept_cd.TabIndex = 10;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(23, 237);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 11;
            this.label8.Text = "부서코드";
            // 
            // ct_papp_basis
            // 
            this.ct_papp_basis.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_basis.Location = new System.Drawing.Point(109, 203);
            this.ct_papp_basis.Name = "ct_papp_basis";
            this.ct_papp_basis.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_basis.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 206);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "발령근거";
            // 
            // ct_papp_auth
            // 
            this.ct_papp_auth.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_auth.Location = new System.Drawing.Point(109, 173);
            this.ct_papp_auth.Name = "ct_papp_auth";
            this.ct_papp_auth.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_auth.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 7;
            this.label6.Text = "발령권자";
            // 
            // ct_papp_appno
            // 
            this.ct_papp_appno.Location = new System.Drawing.Point(109, 52);
            this.ct_papp_appno.Name = "ct_papp_appno";
            this.ct_papp_appno.Size = new System.Drawing.Size(111, 21);
            this.ct_papp_appno.TabIndex = 3;
            this.ct_papp_appno.TextChanged += new System.EventHandler(this.ct_papp_empno_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "인사발령번호";
            // 
            // ct_papp_date
            // 
            this.ct_papp_date.Location = new System.Drawing.Point(109, 83);
            this.ct_papp_date.Margin = new System.Windows.Forms.Padding(3, 4, 3, 3);
            this.ct_papp_date.Mask = "0000-00-00";
            this.ct_papp_date.Name = "ct_papp_date";
            this.ct_papp_date.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_date.TabIndex = 5;
            this.ct_papp_date.ValidatingType = typeof(System.DateTime);
            // 
            // ct_papp_content
            // 
            this.ct_papp_content.ImeMode = System.Windows.Forms.ImeMode.Alpha;
            this.ct_papp_content.Location = new System.Drawing.Point(109, 142);
            this.ct_papp_content.Name = "ct_papp_content";
            this.ct_papp_content.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_content.TabIndex = 7;
            // 
            // ct_papp_pap
            // 
            this.ct_papp_pap.Location = new System.Drawing.Point(109, 112);
            this.ct_papp_pap.Name = "ct_papp_pap";
            this.ct_papp_pap.Size = new System.Drawing.Size(140, 21);
            this.ct_papp_pap.TabIndex = 6;
            // 
            // ct_papp_empno
            // 
            this.ct_papp_empno.Location = new System.Drawing.Point(109, 20);
            this.ct_papp_empno.Name = "ct_papp_empno";
            this.ct_papp_empno.Size = new System.Drawing.Size(111, 21);
            this.ct_papp_empno.TabIndex = 1;
            this.ct_papp_empno.TextChanged += new System.EventHandler(this.ct_papp_empno_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "발령내용";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "발령종류";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "시행일자";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "사원번호";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.papp_empno,
            this.papp_appno,
            this.papp_date,
            this.papp_pap,
            this.papp_content,
            this.papp_auth,
            this.papp_basis,
            this.papp_dept_cd,
            this.papp_pos_cd,
            this.papp_jkp_cd,
            this.papp_dept_nm,
            this.papp_pos_nm,
            this.papp_jkp_nm,
            this.papp_rmk,
            this.status});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(598, 465);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.DataList_SelectionChanged);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // papp_empno
            // 
            this.papp_empno.HeaderText = "사원번호";
            this.papp_empno.Name = "papp_empno";
            // 
            // papp_appno
            // 
            this.papp_appno.HeaderText = "인사발령번호";
            this.papp_appno.Name = "papp_appno";
            // 
            // papp_date
            // 
            this.papp_date.HeaderText = "시행일자";
            this.papp_date.Name = "papp_date";
            // 
            // papp_pap
            // 
            this.papp_pap.HeaderText = "발령종류";
            this.papp_pap.Name = "papp_pap";
            // 
            // papp_content
            // 
            this.papp_content.HeaderText = "발령내용";
            this.papp_content.Name = "papp_content";
            this.papp_content.Width = 120;
            // 
            // papp_auth
            // 
            this.papp_auth.HeaderText = "발령권자";
            this.papp_auth.Name = "papp_auth";
            // 
            // papp_basis
            // 
            this.papp_basis.HeaderText = "발령근거";
            this.papp_basis.Name = "papp_basis";
            // 
            // papp_dept_cd
            // 
            this.papp_dept_cd.HeaderText = "부서코드";
            this.papp_dept_cd.Name = "papp_dept_cd";
            // 
            // papp_pos_cd
            // 
            this.papp_pos_cd.HeaderText = "직급코드";
            this.papp_pos_cd.Name = "papp_pos_cd";
            // 
            // papp_jkp_cd
            // 
            this.papp_jkp_cd.HeaderText = "직책코드";
            this.papp_jkp_cd.Name = "papp_jkp_cd";
            // 
            // papp_dept_nm
            // 
            this.papp_dept_nm.HeaderText = "부서명";
            this.papp_dept_nm.Name = "papp_dept_nm";
            // 
            // papp_pos_nm
            // 
            this.papp_pos_nm.HeaderText = "직급명";
            this.papp_pos_nm.Name = "papp_pos_nm";
            // 
            // papp_jkp_nm
            // 
            this.papp_jkp_nm.HeaderText = "직책명";
            this.papp_jkp_nm.Name = "papp_jkp_nm";
            // 
            // papp_rmk
            // 
            this.papp_rmk.HeaderText = "비고";
            this.papp_rmk.Name = "papp_rmk";
            // 
            // status
            // 
            this.status.HeaderText = "Status";
            this.status.Name = "status";
            this.status.Visible = false;
            // 
            // 인사발령
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 471);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "인사발령";
            this.Text = "인사발령";
            this.Load += new System.EventHandler(this.인사발령_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.data_panel.ResumeLayout(false);
            this.data_panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel data_panel;
        private System.Windows.Forms.TextBox ct_papp_appno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.MaskedTextBox ct_papp_date;
        private System.Windows.Forms.TextBox ct_papp_content;
        private System.Windows.Forms.TextBox ct_papp_pap;
        private System.Windows.Forms.TextBox ct_papp_empno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox ct_papp_basis;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ct_papp_auth;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ct_papp_jkp_nm;
        private System.Windows.Forms.TextBox ct_papp_pos_nm;
        private System.Windows.Forms.TextBox ct_papp_dept_nm;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ct_papp_jkp_cd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ct_papp_pos_cd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ct_papp_dept_cd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ct_papp_rmk;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btn_papp_appno;
        private System.Windows.Forms.Button btn_papp_empno;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_empno;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_appno;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_date;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_pap;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_content;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_auth;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_basis;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_dept_cd;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_pos_cd;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_jkp_cd;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_dept_nm;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_pos_nm;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_jkp_nm;
        private System.Windows.Forms.DataGridViewTextBoxColumn papp_rmk;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
    }
}